@echo off
chcp 65001 >nul
cd /d "%~dp0"
rem Timecode als Sender (DJ-Laptop): schickt die Decks von VirtualDJ, Traktor und
rem rekordbox (rkbx_link) an den Zentral-PC. Nach einem Update oder Rollenwechsel
rem beendet sich Timecode mit Code 42 und wird hier neu gestartet.
set TIMECODE_LAUNCHER=bat
set "TC_ROLE=-sender"
set "TC_RESTART="
:start
Timecode.exe %TC_ROLE% %TC_RESTART% %*
if errorlevel 42 if not errorlevel 43 (
  echo.
  echo Timecode startet neu …
  echo.
  set "TC_ROLE="
  set "TC_RESTART=-no-browser -wait-port"
  goto start
)
pause
