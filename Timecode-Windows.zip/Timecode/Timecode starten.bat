@echo off
chcp 65001 >nul
cd /d "%~dp0"
rem Timecode beendet sich nach einem Update mit Code 42 und wird hier neu gestartet.
set TIMECODE_LAUNCHER=bat
set "TC_RESTART="
:start
Timecode.exe %TC_RESTART% %*
if errorlevel 42 if not errorlevel 43 (
  echo.
  echo Update installiert – starte neu …
  echo.
  set "TC_RESTART=-no-browser -wait-port"
  goto start
)
pause
