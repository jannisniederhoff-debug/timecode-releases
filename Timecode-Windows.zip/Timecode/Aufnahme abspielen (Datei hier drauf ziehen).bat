@echo off
chcp 65001 >nul
cd /d "%~dp0"
if "%~1"=="" (
  echo Bitte eine .tcrec.gz-Datei aus dem Ordner "Aufnahmen" auf diese Datei ziehen.
  pause
  exit /b
)
Timecode.exe -replay "%~1" -loop
pause
