@echo off
chcp 65001 >nul
net session >nul 2>&1
if errorlevel 1 (
  echo Bitte mit Rechtsklick "Als Administrator ausfuehren" starten.
  pause
  exit /b
)
netsh advfirewall firewall delete rule name="Timecode" >nul 2>&1
netsh advfirewall firewall delete rule name="Timecode Pro DJ Link" >nul 2>&1
netsh advfirewall firewall delete rule name="Timecode Sender-Suche" >nul 2>&1
netsh advfirewall firewall delete rule name="Timecode Ableton Link" >nul 2>&1
netsh advfirewall firewall delete rule name="Timecode OS2L" >nul 2>&1
netsh advfirewall firewall delete rule name="Timecode mDNS" >nul 2>&1
netsh advfirewall firewall delete rule name="Timecode StagelinQ" >nul 2>&1
rem Programmregel: erlaubt Timecode.exe alle eingehenden Verbindungen (TCP und UDP,
rem auch die StagelinQ-Dienste der Denon-Player). Die Portregeln unten greifen
rem zusaetzlich, falls die Programmregel nicht passt (z. B. Ordner verschoben).
netsh advfirewall firewall add rule name="Timecode" dir=in action=allow program="%~dp0Timecode.exe" enable=yes profile=any
netsh advfirewall firewall add rule name="Timecode Pro DJ Link" dir=in action=allow protocol=UDP localport=50000-50002 profile=any
netsh advfirewall firewall add rule name="Timecode Sender-Suche" dir=in action=allow protocol=UDP localport=50111 profile=any
rem Ableton Link (Tempo/Beat, Multicast 224.76.78.75)
netsh advfirewall firewall add rule name="Timecode Ableton Link" dir=in action=allow protocol=UDP localport=20808 profile=any
rem OS2L: VirtualDJ verbindet sich auf TCP 9996
netsh advfirewall firewall add rule name="Timecode OS2L" dir=in action=allow protocol=TCP localport=9996 profile=any
rem mDNS/Bonjour: damit VirtualDJ Timecode automatisch findet
netsh advfirewall firewall add rule name="Timecode mDNS" dir=in action=allow protocol=UDP localport=5353 profile=any
rem Denon StagelinQ: Geraete-Erkennung (die TCP-Verbindungen zu den Playern baut Timecode selbst auf)
netsh advfirewall firewall add rule name="Timecode StagelinQ" dir=in action=allow protocol=UDP localport=51337 profile=any
echo.
echo Fertig - Timecode darf jetzt in allen Netzwerken empfangen.
pause
