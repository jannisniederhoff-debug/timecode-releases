@echo off
chcp 65001 >nul
net session >nul 2>&1
if errorlevel 1 (
  echo Bitte mit Rechtsklick "Als Administrator ausfuehren" starten.
  pause
  exit /b
)
netsh advfirewall firewall delete rule name="Timecode" >nul 2>&1
netsh advfirewall firewall delete rule name="Timecode Pro DJ Link" >nul 2>&1
netsh advfirewall firewall add rule name="Timecode" dir=in action=allow program="%~dp0Timecode.exe" enable=yes profile=any
netsh advfirewall firewall add rule name="Timecode Pro DJ Link" dir=in action=allow protocol=UDP localport=50000-50002 profile=any
echo.
echo Fertig - Timecode darf jetzt in allen Netzwerken empfangen.
pause
