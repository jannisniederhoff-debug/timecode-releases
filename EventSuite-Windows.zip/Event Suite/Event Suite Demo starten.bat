@echo off
chcp 65001 >nul
cd /d "%~dp0"
title Event Suite (Demo)
rem Demo: Timecode mit simulierten Playern, Digitalmixer mit virtuellen
rem Soundkarten (kein echter Ton, nichts wird ins Netzwerk gesendet).
rem Laufen Timecode oder Digitalmixer schon normal, werden sie uebernommen -
rem fuer die Demo also vorher alles beenden.
set EVENTSUITE_LAUNCHER=bat
set "ES_RESTART="
:start
EventSuite.exe %ES_RESTART% -demo
if errorlevel 42 if not errorlevel 43 (
  echo.
  echo Update installiert - starte neu ...
  echo.
  set "ES_RESTART=-no-browser -wait-port"
  goto start
)
pause
