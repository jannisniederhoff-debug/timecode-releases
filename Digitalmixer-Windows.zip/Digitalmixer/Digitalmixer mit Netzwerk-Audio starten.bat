@echo off
chcp 65001 >nul
cd /d "%~dp0"
rem Startet den Digitalmixer mit eingeschaltetem Netzwerk-Audio (AES67) und
rem zeichnet dabei eine Netzwerk-Audio-Diagnose im Ordner "Diagnose" auf
rem (bis das Fenster geschlossen wird).
Digitalmixer.exe -netaudio -netaudio-diag "%~dp0Diagnose" %*
pause
