@echo off
chcp 65001 >nul
cd /d "%~dp0"
echo ==============================================================
echo   NETZWERK-AUDIO SUCHEN  (Dante / AES67)  -  es wird nichts veraendert
echo ==============================================================
echo Sucht 30 Sekunden lang nach Dante-/AES67-Geraeten, PTP-Takt und Streams.
echo Ergebnis (.txt) und Diagnose-Datei (.narec.gz) landen im Ordner "Diagnose".
echo.
Digitalmixer.exe -netaudio-scan -netaudio-zeit 30s -netaudio-diag "%~dp0Diagnose" %*
echo.
echo Bitte beide Dateien aus dem Ordner "Diagnose" an den Entwickler schicken.
pause
