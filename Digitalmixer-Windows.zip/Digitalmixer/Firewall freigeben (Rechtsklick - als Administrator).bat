@echo off
chcp 65001 >nul
net session >nul 2>&1
if errorlevel 1 (
  echo Bitte mit Rechtsklick "Als Administrator ausfuehren" starten.
  pause
  exit /b
)
netsh advfirewall firewall delete rule name="Digitalmixer" >nul 2>&1
netsh advfirewall firewall delete rule name="Digitalmixer Weboberflaeche" >nul 2>&1
netsh advfirewall firewall delete rule name="Digitalmixer Netzwerk-Audio" >nul 2>&1
rem Programmregel und Portregel: Handys und Tablets im selben Netz duerfen die
rem Oberflaeche (Port 8090) oeffnen, z. B. die Ansicht "Zonen" fuers Barpersonal.
netsh advfirewall firewall add rule name="Digitalmixer" dir=in action=allow program="%~dp0Digitalmixer.exe" enable=yes profile=any
netsh advfirewall firewall add rule name="Digitalmixer Weboberflaeche" dir=in action=allow protocol=TCP localport=8090-8109 profile=any
rem Netzwerk-Audio (AES67 / Dante-Geraete), alles UDP:
rem   319, 320        PTP-Takt (IEEE 1588)
rem   5353            mDNS (Dante-Geraete finden)
rem   9875            SAP (AES67-Streams ankuendigen/finden)
rem   5004-5099       RTP-Audio der AES67-Streams
rem   4440,4444,4455  Dante-Steuerung (ARC)
rem   8700-8708       Dante-Einstellungen und -Meldungen (Conmon, Heartbeat)
rem   8751,8752       Dante-Pegelanzeigen
rem   8800            Dante-Steuerung (CMC)
netsh advfirewall firewall add rule name="Digitalmixer Netzwerk-Audio" dir=in action=allow protocol=UDP localport=319,320,5353,9875,5004-5099,4440,4444,4455,8700-8708,8751,8752,8800 profile=any
echo.
echo Fertig - Handys im selben Netzwerk erreichen jetzt den Digitalmixer,
echo und Netzwerk-Audio (AES67/Dante) darf empfangen werden.
echo.
echo WICHTIG fuer Netzwerk-Audio: Das Netzwerk, an dem das Dante-Geraet haengt,
echo muss in Windows auf "Privat" stehen (Einstellungen - Netzwerk und Internet -
echo Ethernet - Netzwerkprofiltyp: Privat). Bei "Oeffentlich" blockiert Windows
echo Multicast, dann findet der Digitalmixer nichts.
pause
