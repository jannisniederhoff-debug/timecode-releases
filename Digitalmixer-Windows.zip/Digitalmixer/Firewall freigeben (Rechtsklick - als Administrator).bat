@echo off
chcp 65001 >nul
net session >nul 2>&1
if errorlevel 1 (
  echo Bitte mit Rechtsklick "Als Administrator ausfuehren" starten.
  pause
  exit /b
)
netsh advfirewall firewall delete rule name="Digitalmixer" >nul 2>&1
netsh advfirewall firewall delete rule name="Digitalmixer Weboberflaeche" >nul 2>&1
rem Programmregel und Portregel: Handys und Tablets im selben Netz duerfen die
rem Oberflaeche (Port 8090) oeffnen, z. B. die Ansicht "Zonen" fuers Barpersonal.
netsh advfirewall firewall add rule name="Digitalmixer" dir=in action=allow program="%~dp0Digitalmixer.exe" enable=yes profile=any
netsh advfirewall firewall add rule name="Digitalmixer Weboberflaeche" dir=in action=allow protocol=TCP localport=8090-8109 profile=any
echo.
echo Fertig - Handys im selben Netzwerk erreichen jetzt den Digitalmixer.
pause
