@echo off
chcp 65001 >nul
cd /d "%~dp0"
rem Demo mit virtuellen Soundkarten (kein echter Ton). Nach einem Update (Code 42) startet sie neu.
set DIGITALMIXER_LAUNCHER=bat
set "DM_RESTART="
:start
Digitalmixer.exe %DM_RESTART% -demo
if errorlevel 42 if not errorlevel 43 (
  echo.
  echo Update installiert – starte neu …
  echo.
  set "DM_RESTART=-no-browser -wait-port"
  goto start
)
pause
