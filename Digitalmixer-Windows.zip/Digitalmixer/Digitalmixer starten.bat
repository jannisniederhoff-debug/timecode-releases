@echo off
chcp 65001 >nul
cd /d "%~dp0"
rem Der Digitalmixer beendet sich nach einem Update mit Code 42 und wird hier neu gestartet.
set DIGITALMIXER_LAUNCHER=bat
set "DM_RESTART="
:start
Digitalmixer.exe %DM_RESTART% %*
if errorlevel 42 if not errorlevel 43 (
  echo.
  echo Update installiert – starte neu …
  echo.
  set "DM_RESTART=-no-browser -wait-port"
  goto start
)
pause
