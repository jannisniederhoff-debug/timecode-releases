@echo off
chcp 65001 >nul
cd /d "%~dp0"
if "%~1"=="" (
  echo Bitte eine .tcrec.gz-Datei aus dem Ordner "Aufnahmen" auf diese Datei ziehen.
  pause
  exit /b
)
rem Spielt eine Diagnose-Aufnahme in einem eigenen Timecode ab (Port 8180),
rem neben einer laufenden Event Suite.
Timecode.exe -replay "%~1" -loop -port 8180 -no-update
pause
