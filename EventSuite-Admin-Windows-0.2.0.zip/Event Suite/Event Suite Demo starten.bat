@echo off
chcp 65001 >nul
cd /d "%~dp0"
title Event Suite (Demo)
rem Demo: Timecode mit simulierten Playern, Digitalmixer mit virtuellen
rem Soundkarten, Licht mit virtuellem Art-Net-Node und Demo-Show (kein echter
rem Ton, nichts wird ins Netzwerk gesendet). Die Event Suite gibt -demo an
rem alle Programme weiter. Laufen Timecode, Digitalmixer oder Licht schon
rem normal, werden sie uebernommen - fuer die Demo also vorher alles beenden.
set EVENTSUITE_LAUNCHER=bat
set "ES_RESTART="
:start
EventSuite.exe %ES_RESTART% -demo
if errorlevel 42 if not errorlevel 43 (
  echo.
  echo Update installiert - starte neu ...
  echo.
  set "ES_RESTART=-no-browser -wait-port"
  goto start
)
pause
