@echo off
chcp 65001 >nul
cd /d "%~dp0"
title Event Suite
rem Die Event Suite startet Timecode, den Digitalmixer und Licht selbst (ohne
rem eigene Fenster) und oeffnet die Uebersicht im Browser. Dieses Fenster offen
rem lassen. Nach einem Update beendet sie sich mit Code 42 und wird hier neu
rem gestartet - Timecode, Digitalmixer und Licht laufen dabei weiter.
set EVENTSUITE_LAUNCHER=bat
set "ES_RESTART="
:start
EventSuite.exe %ES_RESTART% %*
if errorlevel 42 if not errorlevel 43 (
  echo.
  echo Update installiert - starte neu ...
  echo.
  set "ES_RESTART=-no-browser -wait-port"
  goto start
)
pause
