@echo off
chcp 65001 >nul
net session >nul 2>&1
if errorlevel 1 (
  echo Bitte mit Rechtsklick "Als Administrator ausfuehren" starten.
  pause
  exit /b
)
rem Gibt alle Programme der Event Suite auf einmal frei (Event Suite, Timecode,
rem Digitalmixer, Licht). Mehrfach ausfuehren schadet nicht: alte Regeln werden ersetzt.
for %%R in ("Event Suite" "Event Suite Timecode" "Event Suite Digitalmixer" "Event Suite Licht" "Event Suite Weboberflaechen" "Event Suite Licht Weboberflaeche" "Event Suite Pro DJ Link" "Event Suite Sender-Suche" "Event Suite Ableton Link" "Event Suite OS2L" "Event Suite mDNS" "Event Suite StagelinQ" "Event Suite Netzwerk-Audio" "Event Suite Art-Net") do (
  netsh advfirewall firewall delete rule name=%%R >nul 2>&1
)
rem Programmregeln: erlauben den vier Programmen alle eingehenden Verbindungen.
rem Die Portregeln unten greifen zusaetzlich (z. B. wenn der Ordner verschoben wurde).
netsh advfirewall firewall add rule name="Event Suite" dir=in action=allow program="%~dp0EventSuite.exe" enable=yes profile=any
netsh advfirewall firewall add rule name="Event Suite Timecode" dir=in action=allow program="%~dp0Timecode.exe" enable=yes profile=any
netsh advfirewall firewall add rule name="Event Suite Digitalmixer" dir=in action=allow program="%~dp0Digitalmixer.exe" enable=yes profile=any
netsh advfirewall firewall add rule name="Event Suite Licht" dir=in action=allow program="%~dp0Licht.exe" enable=yes profile=any
rem Weboberflaechen fuer Handys und Tablets:
rem   8070-8079  Event Suite (Uebersicht)
rem   8080-8099  Timecode
rem   8090-8109  Digitalmixer (z. B. Ansicht "Zonen" fuers Barpersonal)
rem   8100-8109  Licht (Live-Seite fuer Tablets und Handys)
netsh advfirewall firewall add rule name="Event Suite Weboberflaechen" dir=in action=allow protocol=TCP localport=8070-8109 profile=any
rem Timecode: Pro DJ Link (CDJs, DJM), Suche der DJ-Laptops (Sender)
netsh advfirewall firewall add rule name="Event Suite Pro DJ Link" dir=in action=allow protocol=UDP localport=50000-50002 profile=any
netsh advfirewall firewall add rule name="Event Suite Sender-Suche" dir=in action=allow protocol=UDP localport=50111 profile=any
rem Timecode: Ableton Link (Tempo/Beat, Multicast 224.76.78.75)
netsh advfirewall firewall add rule name="Event Suite Ableton Link" dir=in action=allow protocol=UDP localport=20808 profile=any
rem Timecode: OS2L - VirtualDJ verbindet sich auf TCP 9996
netsh advfirewall firewall add rule name="Event Suite OS2L" dir=in action=allow protocol=TCP localport=9996 profile=any
rem mDNS/Bonjour: VirtualDJ findet Timecode, der Digitalmixer findet Dante-Geraete
netsh advfirewall firewall add rule name="Event Suite mDNS" dir=in action=allow protocol=UDP localport=5353 profile=any
rem Timecode: Denon StagelinQ (Geraete-Erkennung)
netsh advfirewall firewall add rule name="Event Suite StagelinQ" dir=in action=allow protocol=UDP localport=51337 profile=any
rem Digitalmixer: Netzwerk-Audio (AES67 / Dante-Geraete), alles UDP:
rem   319, 320        PTP-Takt (IEEE 1588)
rem   9875            SAP (AES67-Streams ankuendigen/finden)
rem   5004-5099       RTP-Audio der AES67-Streams
rem   4440,4444,4455  Dante-Steuerung (ARC)
rem   8700-8708       Dante-Einstellungen und -Meldungen (Conmon, Heartbeat)
rem   8751,8752       Dante-Pegelanzeigen
rem   8800            Dante-Steuerung (CMC)
netsh advfirewall firewall add rule name="Event Suite Netzwerk-Audio" dir=in action=allow protocol=UDP localport=319,320,9875,5004-5099,4440,4444,4455,8700-8708,8751,8752,8800 profile=any
rem Licht: Art-Net - Antworten der Geraete (ArtPollReply) kommen auf UDP 6454
netsh advfirewall firewall add rule name="Event Suite Art-Net" dir=in action=allow protocol=UDP localport=6454 profile=any
echo.
echo Fertig - die Event Suite, Timecode, der Digitalmixer und Licht duerfen
echo jetzt in allen Netzwerken empfangen. Handys im selben Netz erreichen die
echo Oberflaechen (Uebersicht, Timecode, Digitalmixer, Licht-Live-Seite),
echo Licht findet die Art-Net-Geraete.
echo.
echo WICHTIG fuer Netzwerk-Audio: Das Netzwerk, an dem das Dante-Geraet haengt,
echo muss in Windows auf "Privat" stehen (Einstellungen - Netzwerk und Internet -
echo Ethernet - Netzwerkprofiltyp: Privat). Bei "Oeffentlich" blockiert Windows
echo Multicast, dann findet der Digitalmixer nichts. Dasselbe gilt fuer das
echo Netzwerk mit dem Art-Net-Node.
pause
