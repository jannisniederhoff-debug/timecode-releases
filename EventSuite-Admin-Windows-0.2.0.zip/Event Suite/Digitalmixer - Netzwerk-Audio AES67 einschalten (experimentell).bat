@echo off
chcp 65001 >nul
cd /d "%~dp0"
echo ==============================================================
echo   EXPERIMENTELL: AES67 am Dante-Geraet einschalten
echo ==============================================================
echo Vor dem Senden wird das Geraet angezeigt und nach "ja" gefragt.
echo Ohne "ja" wird nichts gesendet. Danach muss das Geraet neu starten.
echo Mehrere Dante-Geraete? Dann den Namen anhaengen, z. B.:
echo   Digitalmixer.exe -netaudio-aes67 on NA-2I2O
echo.
Digitalmixer.exe -netaudio-aes67 on %*
pause
